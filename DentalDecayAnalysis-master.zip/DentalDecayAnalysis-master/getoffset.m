function GLCM_OFFSET = getoffset()
GLCM_OFFSET = dlmread ('GLCM_OFFSET.dat');