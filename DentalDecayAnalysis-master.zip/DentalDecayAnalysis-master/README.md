# DentalDecayAnalysis
X-rays are analyzed and classified into classes of different types of decay.
The application uses image processing methods to classify your sample images into categories,based on your requirement.

Steps to follow:-
1.Download all files into one folder
2.Create a folder training_data
3.In the above mentioned folder create three folders namely cat1 , cat2 ,cat3 which are the three categories with which dental images are classified.
4.Create another folder data which will contain all the sample images which are meant to be classified.
5.Open MATLAB and run the sknn.m file
6.A pop up window will appear on your screen
7.There you must load the folder by clicking the (...) button , then you will notice the three categories loaded on the screen on your right, then click on generate training data.
8.Check for groups.dat file in your training_data folder.
9.Load the sample image and click on classify.
